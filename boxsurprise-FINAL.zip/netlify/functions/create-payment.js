const Stripe = require("stripe");

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

const BOX = {
  amount: 5900,
  description: "Box Surprise",
  code: "742",
};

exports.handler = async function (event) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json",
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }

  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method Not Allowed" }) };
  }

  try {
    const body = JSON.parse(event.body || "{}");

    // Mode aperçu — juste le montant et la description
    if (body.previewOnly) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ amount: BOX.amount, description: BOX.description }),
      };
    }

    // Créer le PaymentIntent Stripe
    const paymentIntent = await stripe.paymentIntents.create({
      amount: BOX.amount,
      currency: "eur",
      description: BOX.description,
      automatic_payment_methods: { enabled: true },
      metadata: {
        boxCode: BOX.code,
        boxDescription: BOX.description,
      },
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        clientSecret: paymentIntent.client_secret,
        amount: BOX.amount,
        description: BOX.description,
        code: BOX.code,
      }),
    };
  } catch (err) {
    console.error("Erreur:", err.message);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: err.message }),
    };
  }
};
